"""Core services for UVAF."""
