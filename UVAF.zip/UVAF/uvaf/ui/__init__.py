"""UVAF graphical interface."""
