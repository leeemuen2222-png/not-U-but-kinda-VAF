from uvaf.app import run

if __name__ == "__main__":
    raise SystemExit(run())
